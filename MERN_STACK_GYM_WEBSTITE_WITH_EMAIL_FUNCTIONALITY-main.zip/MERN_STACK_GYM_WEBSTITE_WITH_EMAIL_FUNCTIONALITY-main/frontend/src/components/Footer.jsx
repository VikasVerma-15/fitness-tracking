import React from 'react'

const Footer = () => {
  return (
    <footer>
        Designed And Developed By CodeWithZeeshu
    </footer>
  )
}

export default Footer
